package com.cdr.model;


import javax.validation.constraints.NotNull;

public class BasicConfiguration {
    @NotNull(message = "Name may not be null")
    public String name;
    public String timezone;
    public String domain;

}

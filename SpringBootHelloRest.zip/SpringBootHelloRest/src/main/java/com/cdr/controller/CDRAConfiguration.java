package com.cdr.controller;

import com.cdr.model.BasicConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/rest/v1/cdra-configuration")
public class CDRAConfiguration {

	private BasicConfiguration basicConfiguration;
	@GetMapping(value = "/basic")
	public ResponseEntity<BasicConfiguration> getBasicConfiguration() {
		return new ResponseEntity<>(basicConfiguration, HttpStatus.OK);
	}

	@PostMapping(value = "/basic/post")
	public ResponseEntity<BasicConfiguration> addBasicConfiguration(@RequestBody BasicConfiguration basicConfiguration) {
		this.basicConfiguration = basicConfiguration;
		return new ResponseEntity<>(basicConfiguration, HttpStatus.CREATED);
	}

	@PutMapping(value = "/basic")
	public ResponseEntity<BasicConfiguration> updateBasicConfiguration(@RequestBody BasicConfiguration basicConfiguration) {
		this.basicConfiguration = basicConfiguration;
		return new ResponseEntity<>(basicConfiguration, HttpStatus.NO_CONTENT);
	}

	
}
